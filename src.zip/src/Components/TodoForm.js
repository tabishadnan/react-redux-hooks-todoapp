import React from 'react';
import { useSelector } from 'react-redux';
import useInputState from '../Hooks/useInputState';
import useAddTodoState from '../Hooks/useAddTodoState';

const TodoForm = () => {

    const data = useSelector(state => state);

    const [value, updateValue] = useInputState(data.name);

    const [todo, setTodo] = useAddTodoState(data.todos);

    return (
        <div>
            <h1>TODOs</h1>
            <p>
            <input type="text" value={value} onChange={updateValue} />
            <button onClick={setTodo}>Add</button>
            </p>
        </div>
    );
}

export default TodoForm;